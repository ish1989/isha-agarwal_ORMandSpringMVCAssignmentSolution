package com.demo;

import java.util.List;

import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationContext;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.GetMapping;

@Controller

public class CustomerController {

	@Autowired // inversion of control for service class
	private CustomerService service;

	public CustomerController() 
	{
		System.out.println("Customer Controller");
	}

	@GetMapping("/")

	public String getCustomer(Map<String, List<Customer>> map) {

		map.put("Customer", service.findAll());
		return "Customerlist"; // returns the name of view

	}

	@GetMapping("/delete")
	public String deleteCustomer(@RequestParam int customerId) {
		this.service.deleteById(customerId);
		return "redirect:/";
	}

	@GetMapping("/add")
	public String addCustomer(Map<String, Customer> map) {
		map.put("Customer", new Customer());
		return "customerform";

	}

	@GetMapping("/update")

	public String updateBook(@RequestParam int customerId, Map<String, Customer> map) {
		System.out.println("update" + customerId);
		Customer customer = this.service.findById(customerId);
		map.put("Customer", customer);
		return "customerform";
	}

	@PostMapping("/save")
	public String save(Customer customer)

	{
		this.service.save(customer);
		return "redirect:/";
	}

}
